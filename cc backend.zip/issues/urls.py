from rest_framework.routers import DefaultRouter
from .views import IssueViewSet, DepartmentViewSet

router = DefaultRouter()
router.register("issues", IssueViewSet, basename="issue")
router.register("departments", DepartmentViewSet, basename="department")

urlpatterns = router.urls