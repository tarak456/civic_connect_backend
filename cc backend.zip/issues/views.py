from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from accounts.models import User
from .models import Issue, Department
from .serializers import IssueSerializer, IssueCreateSerializer, DepartmentSerializer


class IsOwnerOrStaff(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        user = request.user
        if user.role in (User.Role.GOVERNMENT, User.Role.MAINTAINER):
            return True
        return obj.citizen_id == user.id


class IssueViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAuthenticated, IsOwnerOrStaff]

    def get_queryset(self):
        user = self.request.user
        qs = Issue.objects.all()
        if user.role == User.Role.CITIZEN:
            return qs.filter(citizen=user)
        return qs

    def get_serializer_class(self):
        if self.action == "create":
            return IssueCreateSerializer
        return IssueSerializer

    def perform_create(self, serializer):
        serializer.save(citizen=self.request.user)

    @action(detail=False, methods=["get"])
    def assigned_to_me(self, request):
        issues = Issue.objects.filter(assigned_maintainer=request.user)
        return Response(IssueSerializer(issues, many=True).data)

    @action(detail=True, methods=["post"])
    def assign(self, request, pk=None):
        if request.user.role != User.Role.GOVERNMENT:
            return Response({"detail": "Only Government Admins can assign issues."}, status=status.HTTP_403_FORBIDDEN)
        issue = self.get_object()
        department_id = request.data.get("department")
        maintainer_id = request.data.get("assigned_maintainer")
        if department_id:
            issue.department_id = department_id
        if maintainer_id:
            issue.assigned_maintainer_id = maintainer_id
            issue.status = Issue.Status.ASSIGNED
        issue.save()
        return Response(IssueSerializer(issue).data)

    @action(detail=True, methods=["post"])
    def update_status(self, request, pk=None):
        issue = self.get_object()
        new_status = request.data.get("status")
        if request.user.role == User.Role.MAINTAINER:
            allowed = {Issue.Status.IN_PROGRESS, Issue.Status.RESOLVED}
        elif request.user.role == User.Role.GOVERNMENT:
            allowed = set(Issue.Status.values)
        else:
            return Response({"detail": "Citizens cannot change issue status."}, status=status.HTTP_403_FORBIDDEN)
        if new_status not in allowed:
            return Response({"detail": f"Status '{new_status}' not allowed for your role."}, status=status.HTTP_400_BAD_REQUEST)
        issue.status = new_status
        if request.data.get("resolution_notes"):
            issue.resolution_notes = request.data["resolution_notes"]
        issue.save()
        return Response(IssueSerializer(issue).data)

    @action(detail=True, methods=["post"])
    def feedback(self, request, pk=None):
        issue = self.get_object()
        if issue.citizen_id != request.user.id:
            return Response({"detail": "Only the reporting citizen can leave feedback."}, status=status.HTTP_403_FORBIDDEN)
        issue.feedback_rating = request.data.get("feedback_rating")
        issue.feedback_comment = request.data.get("feedback_comment", "")
        issue.save()
        return Response(IssueSerializer(issue).data)


class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    permission_classes = [permissions.IsAuthenticated]
    