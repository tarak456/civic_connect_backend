from rest_framework import serializers
from .models import Issue, Department


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ["id", "name"]


class IssueSerializer(serializers.ModelSerializer):
    citizen_username = serializers.CharField(source="citizen.username", read_only=True)
    department_name = serializers.CharField(source="department.name", read_only=True)

    class Meta:
        model = Issue
        fields = [
            "id", "citizen", "citizen_username", "title", "description", "category", "photo",
            "latitude", "longitude", "address_text", "status", "severity",
            "department", "department_name", "assigned_maintainer",
            "resolution_notes", "resolution_photo", "feedback_rating", "feedback_comment",
            "created_at", "updated_at",
        ]
        read_only_fields = ["id", "citizen", "citizen_username", "department_name", "created_at", "updated_at"]


class IssueCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Issue
        fields = ["title", "description", "category", "photo", "latitude", "longitude", "address_text"]